package com.estockMarket.companyService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class CompanyService {


	public static void main(String[] args) {
		SpringApplication.run(CompanyService.class, args);
	}
}
