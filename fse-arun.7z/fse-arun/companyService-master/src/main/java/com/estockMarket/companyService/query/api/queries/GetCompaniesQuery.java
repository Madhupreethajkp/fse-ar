package com.estockMarket.companyService.query.api.queries;

import lombok.Data;

@Data
public class GetCompaniesQuery {

}
