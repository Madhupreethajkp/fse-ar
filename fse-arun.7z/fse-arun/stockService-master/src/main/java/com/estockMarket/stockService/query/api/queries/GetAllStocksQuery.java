package com.estockMarket.stockService.query.api.queries;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class GetAllStocksQuery {

}
